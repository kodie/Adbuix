#!/bin/bash 

updatefile="http://update.kodieg.com/adbuix.data"
versionfile="/usr/share/adbuix/version.data"
runfile="/usr/bin/Adbuix.gambas"

echo '
Adbuix Updater Version 1.0.1
Updated: 3/25/2010
By Kodie Grantham
http://kodieg.com
'

if [ -z $1 ]; then
	updatefilename=$(basename $updatefile)
	wget $updatefile -qO /tmp/$updatefilename
	updatefile="/tmp/$updatefilename"
	version_new=$(head -n 1 $updatefile | tail -n 1)
	version_current=$(head -n 1 $versionfile | tail -n 1)
	if [[ "$version_new" > "$version_current" ]]; then
		echo
		echo "There is a new version of Adbuix avalible!"
		echo "Your current version: $version_current"
		echo "Latest version: $version_new"
		echo
		echo "Would you like to update Adbuix? [y/n]"
		read a
		if [[ $a == "Y" || $a == "y" || $a = "" ]]; then
			thefile=$(head -n 2 $updatefile | tail -n 1)
			continueupdate=1
		else
			echo "Update Aborted."
		fi
	else
		echo "Your version of Adbuix is up to date."
	fi
else
	echo
	echo "You are about to update Adbuix."
	echo "Would you like to continue? [y/n]"
	read a
	if [[ $a == "Y" || $a == "y" || $a = "" ]]; then
		thefile=$1
		continueupdate=1
	else
		echo "Update Aborted."
	fi
fi

if [ "$continueupdate" == "1" ]; then
	thefilename=$(basename $thefile)
	updatefilename=$(basename $updatefile)

	wget $thefile -O /tmp/$thefilename
	if [ $? -ne 0 ]; then
		echo "An error occurred while trying to download the file."
	else
		sudo gdebi /tmp/$thefilename
		echo
		echo "Update Complete."
		echo "Please restart Adbuix."
	fi

	echo "Deleting Temporary Files..."
	if [ -e "/tmp/$thefilename" ]; then 
		rm /tmp/$thefilename
	fi

	if [ -e "/tmp/$updatefilename" ]; then 
		rm /tmp/$updatefilename
	fi
fi

echo
read -p "Press any key to close..."
exit
